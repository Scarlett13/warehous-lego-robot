package robot.agents;

import jade.core.Agent;
import robot.Constants;
import robot.RobotContext;
import robot.behaviours.command.DestinationReceiverBehaviour;
import robot.behaviours.command.PozyxPositionBehaviour;
import robot.behaviours.pid.SpeedPidBehaviour;
import robot.behaviours.ultrasonic.UltrasonicReadingBehaviour;
import robot.utils.MqttUtil;


public class TeletubbiesAgent extends Agent {

    private final RobotContext ctx = new RobotContext();
    private MqttUtil mqttUtil;

    @Override
    protected void setup() {
        super.setup();
        ctx.instantiatePid();

        try {
            mqttUtil = new MqttUtil(Constants.MQTT_TAG);

            addBehaviour(new DestinationReceiverBehaviour(this, ctx));
            addBehaviour(new PozyxPositionBehaviour(this, 1000 / Constants.LOOP_HZ, ctx, mqttUtil));
            addBehaviour(new UltrasonicReadingBehaviour(this, 1000 / Constants.LOOP_HZ, ctx));
//            addBehaviour(new DummyBehaviour(this, 1000 / Constants.LOOP_HZ, ctx, topicHelper));
//            addBehaviour(new DummyCyclicBehaviour(this, ctx));
            addBehaviour(new SpeedPidBehaviour(this, 1000/Constants.LOOP_HZ, ctx));
        } catch (Exception e) {
            System.err.println(getLocalName()+" topic setup error: "+e.getMessage());
        }

    }

    @Override
    protected void takeDown() {
        super.takeDown();
        try {
            if (mqttUtil != null)
                mqttUtil.shutdown();
        } catch (Exception ignore) {}
    }
}
