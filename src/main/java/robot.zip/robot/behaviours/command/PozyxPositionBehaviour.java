package robot.behaviours.command;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import robot.Constants;
import robot.RobotContext;
import robot.acl.Acl;
import robot.dto.PositionDTO;
import robot.dto.PozyxPointDTO;
import robot.utils.*;

public class PozyxPositionBehaviour extends TickerBehaviour {
    private final AID topic;
    private final RobotContext ctx;
    private final MqttUtil mqttUtil;

    public PozyxPositionBehaviour(Agent a, long period, RobotContext ctx, MqttUtil mqttUtil) {
        super(a, period);
        this.topic = TopicHelper.topic(a, Constants.POSITION_TOPIC);
        this.ctx = ctx;
        this.mqttUtil = mqttUtil;
    }

    @Override
    protected void onTick() {
        if (ctx.getState() != RobotState.WORKING) return;

        long currentTimestamp = System.currentTimeMillis();
        long lastContextTimestamp = ctx.getPosition().getTimestamp();
        if(lastContextTimestamp >= currentTimestamp) return;

        PozyxPointDTO currentPosition = mqttUtil.getLocation();
        float angle = mqttUtil.getAngle();

        PositionDTO positionDto= new PositionDTO(
                currentTimestamp,
                Constants.IS_SIMS ? 1000 : currentPosition.x,
                Constants.IS_SIMS ? 500 : currentPosition.y,
                angle
        );

        ctx.setPosition(positionDto);
        Acl.publish(myAgent, topic, JsonUtil.toJson(positionDto));
//        System.out.println(positionDto);
    }
}
