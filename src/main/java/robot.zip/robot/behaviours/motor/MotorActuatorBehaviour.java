package robot.behaviours.motor;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.MessageTemplate;
import robot.Constants;
import robot.RobotContext;
import robot.acl.Acl;
import robot.utils.Hardware;
import robot.utils.RobotState;
import robot.utils.TopicHelper;

public class MotorActuatorBehaviour extends CyclicBehaviour {
    private final RobotContext ctx;
//    private final AID speedTopic;
//    private final AID turnTopic;
//    private double lastSpeed = 0.0;
//    private double lastTurn = 0.0;
//    private long lastTimestamp = System.currentTimeMillis();
//
//    private final MessageTemplate messageTemplate;

    public MotorActuatorBehaviour(Agent a, RobotContext ctx) {
        super(a);
        this.ctx = ctx;
//        this.speedTopic = TopicHelper.topic(a, Constants.MOTOR_SPEED_TOPIC);
//        this.turnTopic = TopicHelper.topic(a, Constants.MOTOR_TURN_TOPIC);
//        // Listen to either speed or turn topic
//        this.messageTemplate = MessageTemplate.or(Acl.topicTemplate(speedTopic), Acl.topicTemplate(turnTopic));
    }

    @Override
    public void action() {
        if (ctx.getState() != RobotState.WORKING) {
            // If standby, ensure motors stop (one-shot)
//            if (Math.abs(lastSpeed) > 0.0) {
//                Hardware.get().mixer().apply(0.0, 0.0, 0.05);
//                lastSpeed = 0.0; lastTurn = 0.0;
//            }
            block(200);
        }
    }
}
