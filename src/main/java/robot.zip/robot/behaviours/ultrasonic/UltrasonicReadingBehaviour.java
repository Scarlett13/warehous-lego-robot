package robot.behaviours.ultrasonic;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import robot.Constants;
import robot.RobotContext;
import robot.acl.Acl;
import robot.dto.DistanceDTO;
import robot.utils.Hardware;
import robot.utils.JsonUtil;
import robot.utils.RobotState;
import robot.utils.TopicHelper;

public class UltrasonicReadingBehaviour extends TickerBehaviour {
    private final AID topic;
    private final RobotContext ctx;

    public UltrasonicReadingBehaviour(Agent a, long period, RobotContext ctx) {
        super(a, period);
        this.topic = TopicHelper.topic(a, Constants.US_DISTANCE_TOPIC);
        this.ctx = ctx;
    }

    @Override
    protected void onTick() {
        if (ctx.getState() != RobotState.WORKING) return;

        long currentTimestamp = System.currentTimeMillis();
        long lastContextTimestamp = ctx.getDistance().getTimestamp();
        if(lastContextTimestamp >= currentTimestamp) return;

        double distance = Constants.IS_SIMS ? Hardware.get().ultrasonicDummy().readRawSim() : Hardware.get().ultrasonic().readRaw();

        DistanceDTO distanceDto = new DistanceDTO(currentTimestamp, distance > 200 ? 200 : distance);

        ctx.setDistance(distanceDto);
        Acl.publish(myAgent, topic, JsonUtil.toJson(distanceDto));
        System.out.println(distanceDto);
    }

}
