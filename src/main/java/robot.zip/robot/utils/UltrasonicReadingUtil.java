package robot.utils;

import lejos.robotics.SampleProvider;
import java.util.concurrent.ThreadLocalRandom;

public class UltrasonicReadingUtil {
    private final SampleProvider mode;
    private final float[] buf;

    public UltrasonicReadingUtil(SampleProvider distanceMode) {
        this.mode = distanceMode;
        this.buf  = new float[distanceMode.sampleSize()];
    }

    public int sampleSize() {
        return mode.sampleSize();
    }

    public float readRaw() {
        mode.fetchSample(buf, 0);
        return buf[0] > 300 ? 150: buf[0];
    }

    public double readRawSim(){
        double r = ThreadLocalRandom.current().nextDouble(); // [0.0, 1.0)
        if (r < 0.85) return 200.0;   // 85%
        else if (r < 0.95) return 15.0;  // next 10%
        else return 20.0;             // last 5%
    }
}
